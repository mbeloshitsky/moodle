<?php

function xmldb_auth_pop3_install() {
    global $CFG, $DB;

}
