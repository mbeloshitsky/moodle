<?php

function xmldb_auth_nntp_install() {
    global $CFG, $DB;

}
